var $=jQuery.noConflict();
