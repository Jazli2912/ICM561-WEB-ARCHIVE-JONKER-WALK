(function () {
  if (!window.__SHARK_PLUGIN_STATUS__) {
      if (typeof Array.prototype.filter === 'function' &&
          document.cookie.split(';').filter(function (item) {
              return item.indexOf('shark_plugin=1') >= 0
          }).length > 0) {
          window.__SHARK_PLUGIN_STATUS__ = 1;
      } else {
          window.__SHARK_PLUGIN_STATUS__ = 2;
      }
  }
})();
var recentUsedKeyWorker;
try {
  if (location.host.toLowerCase().indexOf('localhost') < 0 &&
      location.host.toLowerCase().indexOf('.dev.') < 0 &&
      window.Worker && window.URL && window.Blob && window.Set && !recentUsedKeyWorker) {
      var pageEle = document.getElementById('page_id');
      var pageid = (pageEle && pageEle.value) || '';
      var tripHost = 'dynamic';
      if (tripHost === 'dynamic') {
          tripHost = (/pro_ctripwireless|ctrip_ctripwireless/.test(navigator.userAgent.toLowerCase()) || /(ctrip|ctripcorp|lvtds)\.com/.test(location.host)) ? 'https://www.ctrip.com' : 'https://www.trip.com';
      }
      function __SHARK_REPORT_WORKER__(tripHost) {
          var xmlHttp = new XMLHttpRequest();
          var xmlHttp2 = new XMLHttpRequest();
          var history_set = new Set();
          var keyinfo_cache = [];
          onmessage = function (e) {
              if (history_set.size < 5000 && !history_set.has(e.data)) {
                  keyinfo_cache.push(e.data);
                  history_set.add(e.data);
              }
          };
          setInterval(function () {
              if (xmlHttp !== null && xmlHttp2 !== null && keyinfo_cache.length > 0) {
                  try {
                      var undefinedKeys = [], recentUsedKeys = [];
                      keyinfo_cache.forEach(function (key) {
                          if (key[0] !== '!') {
                              recentUsedKeys.push(key);
                          } else {
                              undefinedKeys.push(key.substr(1));
                          }
                      });
                      if (recentUsedKeys.length) {
                          xmlHttp.open('POST', tripHost + '/m/i18n/ReportRecentUsedKey.html', true);
                          xmlHttp.setRequestHeader('content-type', 'application/json;charset=utf-8');
                          xmlHttp.send(JSON.stringify(recentUsedKeys));
                      }
                      if (undefinedKeys.length) {
                          xmlHttp2.open('POST', tripHost + '/m/i18n/ReportUndefinedKeys.html', true);
                          xmlHttp2.setRequestHeader('content-type', 'application/json;charset=utf-8');
                          xmlHttp2.send(JSON.stringify(undefinedKeys));
                      }
                      keyinfo_cache = [];
                  } catch (err) {
                  }
              }
          }, 5000);
      }

      recentUsedKeyWorker = new Worker(URL.createObjectURL(new Blob(['(' + __SHARK_REPORT_WORKER__.toString() + ')(' + "'" + tripHost + "'" + ')'])));
  }
} catch (err) {
}
;(function (name, definition) {
  var LANGUAGE = {"key.experience":"Experience","t_mn_sh_3002":"To","key.review_detail_related_more":"More reviews","f_lt_tl_2027":"Subclass","f_lt_tl_2028":"Notes","key.weather_humidity":"Relative Humidity","key.no_search_results_subtitle":"Please adjust your search filters and try again.","key.article_list_all":"Travelogue","key.recent_searches":"Recent Searches","key.cancel":"Cancel","key.weather_sunrise":"Sunrise","key.no_search_results":"No Search Results\nPlease adjust your search and try again","wwy_child_age":"Please select the child\u0027s age.","key.view_number":"%1$s views","key.poilist_h1":"Attractions in %1$s","key.food_Flavor":"Local Favorites","key.map":"Map","resx.flightresource.page_chflight_list1_title":"[cityA] to [cityD] flights | Trip.com","TWD":"Neuer Taiwan Dollar","f_lt_tl_2010":"Change","key.des_unique_experience":"Best Experience in %1$s","f_lt_tl_2011":"Endorsement","key.no_results_found_in_your_current_destination":"No results found for this destination","key_home_subtitle":"With the Free Trip.com App！","MYR":"Malaysische Ringgit","Page_Hotel_Index_New_KeyWord":"cheap hotels, hotels, accommodation, hotel reservations, China hotels, Trip.com","key.detail":"detail","optional":"Optional","key.XXX_photos":"%1$s photos","key.where_to_stay":"Popular Hotels","key.norestaurant":"No TOP Restaurants","resx.flightresource.page_home_index_key":"cheap flights, flights, airline tickets, airfares, cheap airfares, Trip.com","key.food_star":"TOP Star","key.mentioned_attractions":"Referenced Attractions","key.more_photos_about":"Related Photos","key.travelphotolist_meta_title":"The photos in %1$s from travelers - Trip.com","key.average":"avg per person","key.weather_sunset":"Sunset","key.dest_ranking_list":"Inspiration","key.restaurants":"Restaurants","key.des_best_time":"Best Time To Visit","key.take_aways":"Featured Places","key.see.all":"See All","key.des_electric":"Socket/Plug","key.search_placeholder":"Destination, attraction, hotel, etc","key.openapp2":"Use the Trip.com app to view more great offers","key.poi_nearby_attraction":"Attractions Nearby","key.weather_datasource":"Data provided by %1$s","key.top_thing_to_do_btn":"Popular Attractions","resx.flightresource.page_chflight_list1_key":"Cheap [cityA] to [cityD] flights, [cityA] to [cityD] flight, [cityA] to [cityD] airlines, cheap [cityA] to [cityD] flight tickets, book [cityA] to [cityD] flights, mobile air ticket booking, Trip.com","key.share_your_photos":"Why not upload your photos of the attraction?","THB":"Thailändischer Baht","key.travelers_reviews":"Traveler Reviews","key.open_in_safafi":"Tap \"…\" in the upper right and select \"Open in Safari\"","RUB":"Russische Rubel","key.poi_tickets":"Tickets","f_lt_tl_2030":"Ticket policy","key.retry":"Try Again","key.tickets_and_tours_btn":"Tours \u0026 Tickets","key.recently_search":"Recently Search","confirm":"Confirm","key.poi_all_category":"All Categories","SGD":"Singapur-Dollar","key.common.photobrowser.desc":"Tripadvisor, Click to view the most recent photos","key.footlink_des_poprest":"Recommended Restaurants in %1$s","key.view_number_1":"%1$s view","key.add_trip_fail":"Failed to add","key.about":"About this Attraction","key.link_hotel_in":"Hotels in %1$s","key.you_have_submit":"You have already submitted a review for this attraction today","key.select_the_type_of_report":"Report this Review","key.airport":"Airport","CHF":"Schweizer Franken","c_1006":"Policies \u0026 Baggage","key.price_desc":"Price (High to low)","key.des_hot_season":"Peak Season","c_1005":"{0} transfer(s)","c_1008":"Some segments operated by {0}","c_1007":"Few Left","c_1009":"Quick Ticketing","key.xxx_recommended_restaurants":"%1$s Recommended Restaurants","enter_destination":"Please enter a destination","resx.flightresource.page_flight_list1_description":"Book cheap flights from [cityA] to [cityD] with Trip.com. Find cheap tickets to and from over 5,000 destinations around the world.","AUD":"Australischer Dollar","key.search_destinations":"Destination or attraction","key.review_from.xxx":"from","key.tours":"Activities and Tours","IDR":"Indonesische Rupiah","key.food_selected":"TOP Selected","key.restaurant_all_cuisines":"All Cuisines","key.clear":"Clear","c_1011":"{0} to {1} yrs old only","key_footer_copyright":"Copyright © 1999-2019 Trip.com. All rights reserved","key.recommended_tags":"Explore More","c_1010":"Hotel Promo Code","key.mentioned_destinations":"Referenced Destinations","c_1013":"{0} to {1} passengers only","c_1012":"{0} yrs old and over","c_1015":"Only available to citizens of {0}.","c_1014":"Bookings of {0} passenger(s) only","key.ttd_sales":"%1$s% OFF","c_1017":"Low-cost Cancellation Within 24 Hours","key.original_text":"Original Text","c_1016":"Not available to citizens of {0}.","c_1019":"Retry","c_1018":"Operated by","key.food_price_best":"Price","key.attraction.in.xxx":"Attractions in %1$s","key.travelphoto_meta_title":"Travelers\u0027 photos in %1$s","key.des_language":"Language","key.common.photobrowser.source":"Source","key.more":"More","key.traffic":"Airports","f_mn_sh_3007":"Depart","f_mn_sh_3006":"Class","key.food_recommend_dish":"What to Eat","f_mn_sh_3008":"Return","key.what_to_eat":"Food in %1$s","c_1020":"No more results","f_mn_sh_3001":"Round trip","key.submit_a_failure":"Whoops! Something went wrong. Please check your network settings and try again.","key.food_total":"All","key.food_actionsheet_remove":"Cancel","f_mn_sh_3003":"Economy","f_mn_sh_3002":"One-way","key.What_to_eat_btn":"Food","f_mn_sh_3005":"First","key.des_transpotation":"%1$s Transportation","f_mn_sh_3004":"Business","key.openning_hours":"Opening Hours","key.view_more":"Show More","key.more_restaurant_in_XXX":"More Restaurants in %1$s","key_home_install":"Install","key.report_success":"Report sent","key.des_travel_tips_btn":"Travel Tips","key.restaurantlist_h1":"Restaurants in %1$s","key.no_results":"No results found","key.poi_tours":"Tours","key.food_check_xx_top_restaurant":"View the %1$s TOP Restaurant Ranking","key.sight.ranking.recommend":"Attractions","key.footlink_pophotel":"Popular Hotels","f_mn_lt_1004":"Loading failed, please reload to try again.","key.des_emergency_contacts":"Emergency Phone Numbers","GBP":"Britisches Pfund","key.showmore":"Show More","key.travelphotolist_meta_keywords":"%1$s, %1$s photos, the travelers in %1$s, photos from travelers","number_of_guests_per_room":"Guests Per Room","key.spamming":"Spam","key.travel_experience":"Travelogue","key.view_website":"Official website","key.article_list_title":"Tagged with \"%1$s\"","f_mn_sh_3014":"Departure city must be different with arrival city.","key_myctrip_about_us2":"Trusted Online Travel Leader","f_mn_sh_3015":"From","key.relate_to_POI":"You Might Also Like","key.map.detail":"Map","key.photos_review_count.xxx":"%1$s reviews","key.food_xx_restaurant":"Restaurants in %1$s","key.search_prompt":"For more cities, please use the search box.","key.no_eval":"No reviews yet","key.jumping":"Launching the Trip.com App","key.tickets_and_tours":"Tours \u0026 Tickets","key.local_specialties":"Specialty Dishes","key.all_destinations":"All Destinations","key.where_to_stay_btn":"Popular Hotels","key.please_add_the_comment_content":"Please include a brief review","f_mn_sh_3023":"Please provide departure date.","key.weather_forecast":"6-Day Forecast","key.search_destinations_placeholder":"Search destinations","c_1002":"Install","key.from":"from","key.poi_no_content_subtitle":"No attraction information is currently available for this destination.","c_1001":"Save up to 50%\u003cbr /\u003ewith the Trip.com app!","f_mn_sh_3024":"Please provide return date","key.hotel_nearby":"Hotels Nearby","c_1004":"{0} stop(s)","key.travel_experience_btn":"Travel Experience","c_1003":"No thanks","f_mn_sh_3026":"Date","key.open_in_browser":"Tap \"…\" in the upper right and select \"Open with Browser\"","key.weather_today":"Today","key.where_to":"Where to?","key.distance_km":"km","key.experience.in.xxx":"Experience in %1$s","key.relate_to_dest":"Recommended Destinations","key.poi_book":"Book","key.my_review":"My Review","key.food_top_restaurant":"TOP Restaurants","key.distance":"Distance (Near to far)","key.review":"Reviews","key.near_by":"Nearby","key.attraction_review":"%1$s User Photo","f_bk_tl_1047":"OK","key.photo_like_count.xxx":"%1$s likes","key.travelphotolist_meta_description":"You can see the real photos of %1$s by differents travelers, and find the beauitful sencery or special experience in %1$s.","key.food_search_placeholder":"Restaurant","key.tap_circle_to_rate":"Give it a rating","key.popular_destnations":"Popular Destinations","resx.flightresource.page_home_index_description":"Get cheap flights! Search for airline tickets, and book with Trip.com to save up to 55% on your airfare. Browse flight schedules international flights and save on flight tickets!","key.openapp":"Open the Trip.com app?","key.compromise_national_security":"Harmful to national security","key.footlink_des_poppoi":"Popular Attractions in %1$s","key.show_more":"Loading more results...","key_home_bookHotelsFlightsAndTrains":"Save up to 50%","key.distance_from_user":"%1$s away","key.view_more_reviews":"Show All Reviews","key.des_helpful_info":"Helpful Information About %1$s","resx.flightresource.page_flight_list1_key":"Cheap [cityA] to [cityD] flights, [cityA] to [cityD] flight, [cityA] to [cityD] airlines, cheap [cityA] to [cityD] flight tickets, book [cityA] to [cityD] flights, mobile air ticket booking, Trip.com","key.local_time":"Local time","resx.flightresource.page_home_index_title":"Cheap flights, airline tickets \u0026 airfares 55% OFF | Trip.com","key.content_error":"False information","key.xxx_specialties":"%1$s Specialty Dishes","f_lt_24":"Low-cost Cancellation Within 24 Hours","key.restaurant_all_restaurant":"All Specialty Dishes","key.add_trip_success":"Added","f_2017_1020":"All segments operated by {0}","key.homepage_h1":"Attractions","CNY":"Chinesisches Yuan","key.top_things_to_do":"Popular Attractions","f_mn_lt_1049":"Details","key.poi_review_note":"Some user reviews have been automatically translated","f_mn_lt_1047":"Operated by","f_2017_1017":"\u003c5 Left","key.bloghome_tag_destination":"Destinations","key.weather_tomorrow":"Tomorrow","key.Top_city_incountry":"Popular Cities","PHP":"Philippinische Peso","f_2017_1019":"Change","f_2017_1018":"Book","key.permission.photo":"Please give the Trip.com app permission to access your photos","c_2004":"Cancel","key.no_result":"Whoops! Something went wrong. Please check your network settings and try again.","key.please_select_the_score":"Please rate this attraction","key.add_trip":"Add to My Trips","key.photos_from_travelers":"User Photos","key.other_tips":"Special Events","key.reviews":"Reviews","key.footlink_popdes":"Popular Destinations","common.network.error":"Whoops! Something went wrong. Please check your network settings and try again.","key.footlink_des_pophotel":"Popular Hotels in %1$s","key.poi_more_tous":"More Tours Related to %1$s","USD":"US-Dollar","key.search_attracations_in_XXX":"Search Attractions in %1$s","key.restaurants_nearby":"Restaurants Nearby","key.report":"Report","f_mn_lt_1050":"Retry","key.railwaystation":"Train Station","f_2017_1001":"Hide","key.blog_home_recommended":"Recommendations","f_2017_1005":"Policies \u0026 Baggage","f_2017_1004":"{0} transfer(s)","f_2017_1003":"{0} stop(s)","key.results_about":"Results related to \"%1$s\"","key.write_a_review":"Write a Review","key.recommended_resturant":"Recommendations","c_2013":"No results found.","f_mn_sh_5007":"All airports","key.recently_view":"Recently Viewed","f_mn_sh_5005":"Please try different keywords or select a city from the list.","key.des_time":"Time Zone","key.no_network":"No Internet Connection","key.travel_tips":"Helpful Information","key.open_time":"Business Hours","resx.flightresource.page_flight_list1_title":"[cityA] to [cityD] flights | Trip.com","key.poi_tickets_from":"from %1$s","key.recommended":"Recommended","f_2017_1042":"When transfering in [{0}], you may need to complete the entry/exit procedures, collect your baggage, and check in again. Please ensure you have the necessary travel documents/visas for the countries/regions where you will transfer. Free checked baggage allowance may vary between bookings. Please refer to the regulations for details.","f_2017_1035":"Trip.com Self-Transfer Package Guarantee","f_2017_1034":"Passengers are responsible for any costs caused if they are unable to board the plane due to reasons including but not limited to flight delays or cancellation, missing travel documents and insufficient transit time.","f_2017_1033":"What if I miss my flight?","f_2017_1032":"A self-transfer package includes several flights combined by Trip.com into one itinerary. These flights are operated by different airlines that do not have a shared ticketing agreement. After booking, this package will be separated into several bookings and the tickets will be issued individually. Changes and cancellations for each booking will be subject to the individual airline\u0027s regulations and policies, and must be dealt with separately.","key.address":"Address","c_3030":"City or airport","f_2017_1039":"Self-Transfer Package","f_2017_1037":"Learn More","key.poi_more_tickets":"More tickets at %1$s","f_2017_1036":"If you are unable to take connecting flights due to one of your flight segments being canceled or changed by the airline, we will ensure that you get to your destination, or will offer you a refund for all your affected unused flight segments.","key.home.more_destination":"More Destinations","key.sex_and_violence":"Sexually explicit/Violent","f_bk_mn_1056":"Passenger","TRY":"Turkish Lira","key.translate":"Translate","Hotel_Filter_Apply":"Apply","key.no_search_results_title":"No results found","c_3038":"Please provide arrival city.","c_3037":"Please provide departure city.","HKD":"Hongkong-Dollar","key.food_distance":"Distance","key.distance_from_city_center":"%1$s from downtown","key.share_to":"Share","EUR":"Euro","key.bloghome_tag_experience":"Experiences","CAD":"Kanadische Dollar","key.poi_list_nearby_tag":"Nearby Attractions","key.related_to_item":"You Might Also Like","key.footlink_poppoi":"Popular Attractions","f_2017_1031":"What is a self-transfer package?","f_2017_1030":"Partially used","key.others":"Other","key.restaurant_cuisines":"Cuisines","f_2017_1024":"Under {0} yrs old only","key.view_this_attraction":"Show Attraction Info","f_2017_1023":"Book","f_2017_1022":"Total","f_2017_1021":"Avg","c_3041":"Business","f_2017_1028":"Baggage Allowance","key.XXX_reviews":"%1$s reviews","key.traffic_tips":"Getting Around","c_3042":"First","f_2017_1027":"Whoops, we\u0027ve encountered a technical issue. Please try again later.","Page_Home_Index_title":"Cheap hotels \u0026 accommodation reservations, 50% off | Trip.com","f_2017_1026":"When transfering in [{0}], you may need to complete the entry/exit procedures, collect your baggage, and check in again. Please ensure you have the necessary travel documents/visas for the countries/regions where you will transfer. Free checked baggage allowance may vary between bookings. Please refer to the regulations for details.","key.poi_nearby_hotel":"Hotels Nearby","f_2017_1025":"Self-Transfer Package","c_3040":"Economy","key.search_results_in_other_destinations":"Search Results for Other Destinations","f_2017_1029":"Unused","key.destinations":"Destination","c_3009":"Language","key.XXX_attactions":"%1$s attractions","key.power_by_ctrip_photo_wall":"Powered by Ctrip","key.please_share_the_experience":"What is it like? What do you recommend visitors check out?","key.popular_attracations":"Popular Attractions","f_lt_tl_2005":"Special price only available to citizens of {0}.","f_lt_tl_2006":"Special price not available to citizens of {0}.","key.distance_from_here":"%1$s from here","key.load_more":"Load More","f_lt_tl_2008":"Price per passenger","key.travelphoto_meta_description":"See the photos of %1$s by the travelers, maybe you can get more idea of %1$s.","INR":"Indische Rupie","f_lt_tl_2002":"This fare is only available for bookings of {0}-{1} passengers.","f_lt_tl_2003":"Special price only available to passengers aged between {0} and {1}.","key.view_more_article":"Load More","f_lt_tl_2004":"Special price only available to passengers aged over {0}.","key.food_hot_restaurant":"Popular Restaurants","f_2017_1056":"No matching flights found. Please adjust your filters and try again.","KRW":"Koreanische Won","key.blog_hometitle":"Travel the World with Trip","JPY":"Japanische Yen","PLN":"Polnischer Zloty","key.get_to_kown_XXX":"About %1$s","f_lt_tl_2009":"Refund","Page_Hotel_Index_New_Description":"Trip.com offers big savings on around 1,200,000 hotels in 200 countries and territories around the world. Make cheap accommodation reservations at hotels and hostels. Save 50%!","key.poi_nearby_restaurant":"Restaurants Nearby","key.top_attraction":"Popular","c_3012":"Flights","key.food_list_recommended":"Recommended","c_3013":"Trains","key.restaurant_filter":"Filter","key.price_asc":"Price (Low to high)","c_3010":"Currency","key.asia":"Asia","key.attractions":"Attraction","c_3011":"Hotels","key.submit":"Submit","key.recommended_articles":"What\u0027s Trending","key.distance_m":"m","key.photos_post_on.xxx":"Posted %1$s","key.des_travel_tips":"%1$s Travel Tips","c_3019":"Search","key.submit_success":"Submitted","key.hotels":"Hotels","key.blog_home_latest":"Most Recent","key.travelphoto_meta_keywords":"%1$s, %1$s photos, the travelers in %1$s, photos from travelers","key.viewed_number":"%1$s Views","key.nearby_attracations":"Nearby Attractions","key_menu_home":"Home","key_use_cookie":"By using this website, you are deemed to consent to our {Use of Cookies}.","resx.flightresource.page_chflight_list1_description":"Book cheap flights from [cityA] to [cityD] with Trip.com. Find cheap tickets to and from over 5,000 destinations around the world.","key.US_Europe_other":"The Americas, Europe \u0026 Other","c_3023":"Plan a trip","key.openapp_confirm":"Confirm","c_3024":"About Us","NZD":"Neuseeland-Dollar","key.des_currency":"Currency","BRL":"Brasilianischer Real","f_bk_mn_1028":"This fare is only available for bookings of {0} passengers. ","key.more_attactions_in_XXX":"More %1$s Attractions","c_3026":"Privacy Statement"};
  if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__) {
      window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__ = {};
  }
  if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100017292']) {
      window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100017292'] = LANGUAGE
  } else {
      if (typeof Object.assign !== 'function') {
          for (var key in LANGUAGE) {
              window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100017292'][key] = LANGUAGE[key]
          }
      } else {
          window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100017292'] = Object.assign(
              window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100017292'],
              LANGUAGE
          )
      }
  }
  var hasDefine = typeof define === 'function' && define.amd,
      hasExports = typeof module !== 'undefined' && module.exports;
  if (hasDefine) {
      if (!window.__shark_app_defined) {
          define(definition);
          window.__shark_app_defined = true;
      }
      define('i18n_100017292', definition);
  } else if (hasExports) {
      module.exports = definition();
  } else {
      this[name] = definition();
  }
})('i18n_100017292', function () {
  var LANGUAGE = window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100017292'];
  if (typeof Proxy === 'function') {
      var LANGUAGE_PROXY = new Proxy(LANGUAGE, {
          get: function (target, property) {
              if (typeof property === 'symbol') {
                  return property;
              } else if (property in target) {
                  if (recentUsedKeyWorker) {
                      recentUsedKeyWorker.postMessage("100017292|en-XX|" + property + (pageid ? '|' + pageid : ''));
                  }
                  if (window.__SHARK_PLUGIN_STATUS__ && window.__SHARK_PLUGIN_STATUS__ === 1) {
                      return '<i data-key=\'' + property + '\' data-appid=\'100017292\'>' + target[property] + '</i>';
                  }
                  return target[property];
              } else {
                  
                  if (recentUsedKeyWorker && property !== '__esModule') {
                      recentUsedKeyWorker.postMessage("!100017292|en-XX|" + property + (pageid ? '|' + pageid : ''));
                  }
                  return null;
              }
          },
          set: function (target, property, value) {
              target[property] = value;
              return true;
          }
      });
      return LANGUAGE_PROXY;
  }
  return LANGUAGE;
});


