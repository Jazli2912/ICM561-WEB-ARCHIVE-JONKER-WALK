(function () {
  if (!window.__SHARK_PLUGIN_STATUS__) {
      if (typeof Array.prototype.filter === 'function' &&
          document.cookie.split(';').filter(function (item) {
              return item.indexOf('shark_plugin=1') >= 0
          }).length > 0) {
          window.__SHARK_PLUGIN_STATUS__ = 1;
      } else {
          window.__SHARK_PLUGIN_STATUS__ = 2;
      }
  }
})();
var recentUsedKeyWorker;
try {
  if (location.host.toLowerCase().indexOf('localhost') < 0 &&
      location.host.toLowerCase().indexOf('.dev.') < 0 &&
      window.Worker && window.URL && window.Blob && window.Set && !recentUsedKeyWorker) {
      var pageEle = document.getElementById('page_id');
      var pageid = (pageEle && pageEle.value) || '';
      var tripHost = 'dynamic';
      if (tripHost === 'dynamic') {
          tripHost = (/pro_ctripwireless|ctrip_ctripwireless/.test(navigator.userAgent.toLowerCase()) || /(ctrip|ctripcorp|lvtds)\.com/.test(location.host)) ? 'https://www.ctrip.com' : 'https://www.trip.com';
      }
      function __SHARK_REPORT_WORKER__(tripHost) {
          var xmlHttp = new XMLHttpRequest();
          var xmlHttp2 = new XMLHttpRequest();
          var history_set = new Set();
          var keyinfo_cache = [];
          onmessage = function (e) {
              if (history_set.size < 5000 && !history_set.has(e.data)) {
                  keyinfo_cache.push(e.data);
                  history_set.add(e.data);
              }
          };
          setInterval(function () {
              if (xmlHttp !== null && xmlHttp2 !== null && keyinfo_cache.length > 0) {
                  try {
                      var undefinedKeys = [], recentUsedKeys = [];
                      keyinfo_cache.forEach(function (key) {
                          if (key[0] !== '!') {
                              recentUsedKeys.push(key);
                          } else {
                              undefinedKeys.push(key.substr(1));
                          }
                      });
                      if (recentUsedKeys.length) {
                          xmlHttp.open('POST', tripHost + '/m/i18n/ReportRecentUsedKey.html', true);
                          xmlHttp.setRequestHeader('content-type', 'application/json;charset=utf-8');
                          xmlHttp.send(JSON.stringify(recentUsedKeys));
                      }
                      if (undefinedKeys.length) {
                          xmlHttp2.open('POST', tripHost + '/m/i18n/ReportUndefinedKeys.html', true);
                          xmlHttp2.setRequestHeader('content-type', 'application/json;charset=utf-8');
                          xmlHttp2.send(JSON.stringify(undefinedKeys));
                      }
                      keyinfo_cache = [];
                  } catch (err) {
                  }
              }
          }, 5000);
      }

      recentUsedKeyWorker = new Worker(URL.createObjectURL(new Blob(['(' + __SHARK_REPORT_WORKER__.toString() + ')(' + "'" + tripHost + "'" + ')'])));
  }
} catch (err) {
}
;(function (name, definition) {
  var LANGUAGE = {"key.blog.filter.items.all":"ALL","key.XXX_attactions":"%1$s attractions","key.trip.community.detail.train.oneway":"One-way","key.blog.hotel.detail.download":"View in App","key.photos_review_count.xxx":"%1$s reviews","key.trip.community.detail.train.shortest":"Lowest Price","key.community.detail.restaurant.average":"Average price per person","key.blog.card.cruise.tonnage":"Tonnage: %1$s t","key.rank.view":"View","key.trip.community.departdate":"Departure date: ","key.community.detail.restaurant.book":"Book","key.blog.hotel.detail":"Details","key.trip.community.detail.train.startprice":"Starting price","key.community.detail.restaurant.appbook":"book","key.blog.card.cruise.service":"Entered service in: %1$s","key.blog.tnt.card.book":"Book Now","key.blog.card.cruise.capacity":"Guest capacity: %1$s","key.view_less":"Show Less","key.blog.detail.destinationcard.posts":"%1$s posts","key.trip.community.detail.lowprice":"Lowest price within the next 30 days","key.more_info":"More info"};
  if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__) {
      window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__ = {};
  }
  if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100025440']) {
      window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100025440'] = LANGUAGE
  } else {
      if (typeof Object.assign !== 'function') {
          for (var key in LANGUAGE) {
              window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100025440'][key] = LANGUAGE[key]
          }
      } else {
          window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100025440'] = Object.assign(
              window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100025440'],
              LANGUAGE
          )
      }
  }
  var hasDefine = typeof define === 'function' && define.amd,
      hasExports = typeof module !== 'undefined' && module.exports;
  if (hasDefine) {
      if (!window.__shark_app_defined) {
          define(definition);
          window.__shark_app_defined = true;
      }
      define('i18n_100025440', definition);
  } else if (hasExports) {
      module.exports = definition();
  } else {
      this[name] = definition();
  }
})('i18n_100025440', function () {
  var LANGUAGE = window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100025440'];
  if (typeof Proxy === 'function') {
      var LANGUAGE_PROXY = new Proxy(LANGUAGE, {
          get: function (target, property) {
              if (typeof property === 'symbol') {
                  return property;
              } else if (property in target) {
                  if (recentUsedKeyWorker) {
                      recentUsedKeyWorker.postMessage("100025440|en-XX|" + property + (pageid ? '|' + pageid : ''));
                  }
                  if (window.__SHARK_PLUGIN_STATUS__ && window.__SHARK_PLUGIN_STATUS__ === 1) {
                      return '<i data-key=\'' + property + '\' data-appid=\'100025440\'>' + target[property] + '</i>';
                  }
                  return target[property];
              } else {
                  
                  if (recentUsedKeyWorker && property !== '__esModule') {
                      recentUsedKeyWorker.postMessage("!100025440|en-XX|" + property + (pageid ? '|' + pageid : ''));
                  }
                  return null;
              }
          },
          set: function (target, property, value) {
              target[property] = value;
              return true;
          }
      });
      return LANGUAGE_PROXY;
  }
  return LANGUAGE;
});


