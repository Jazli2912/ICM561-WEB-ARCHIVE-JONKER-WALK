;(function (name, definition) {
    var LANGUAGE = {"2020-04-12":"Easter","2020-01-01":"New Year\u0027s Day","2019-12-25":"Christmas Day","2020-12-25":"Christmas Day","2020-12-24":"Christmas Eve","2020-10-31":"Halloween","2020-12-31":"New Year\u0027s Eve"};
    if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__) {
        window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__ = {};
    }
    if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_6001']) {
        window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_6001'] = LANGUAGE
    } else {
        if (typeof Object.assign !== 'function') {
            for (var key in LANGUAGE) {
                window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_6001'][key] = LANGUAGE[key]
            }
        } else {
            window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_6001'] = Object.assign(
                window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_6001'],
                LANGUAGE
            )
        }
    }
    var hasDefine = typeof define === 'function' && define.amd,
        hasExports = typeof module !== 'undefined' && module.exports;
    if (hasDefine) {
        if (!window.__shark_app_defined) {
            define(definition);
            window.__shark_app_defined = true;
        }
        define('i18n_6001', definition);
    } else if (hasExports) {
        module.exports = definition();
    } else {
        this[name] = definition();
    }
})('i18n_6001', function () {
    var LANGUAGE = window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_6001'];
    return LANGUAGE;
});


