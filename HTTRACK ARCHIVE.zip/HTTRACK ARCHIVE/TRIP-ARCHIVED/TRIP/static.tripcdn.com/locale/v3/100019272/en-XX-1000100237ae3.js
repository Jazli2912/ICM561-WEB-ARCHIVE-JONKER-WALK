(function () {
  if (!window.__SHARK_PLUGIN_STATUS__) {
      if (typeof Array.prototype.filter === 'function' &&
          document.cookie.split(';').filter(function (item) {
              return item.indexOf('shark_plugin=1') >= 0
          }).length > 0) {
          window.__SHARK_PLUGIN_STATUS__ = 1;
      } else {
          window.__SHARK_PLUGIN_STATUS__ = 2;
      }
  }
})();
var recentUsedKeyWorker;
try {
  if (location.host.toLowerCase().indexOf('localhost') < 0 &&
      location.host.toLowerCase().indexOf('.dev.') < 0 &&
      window.Worker && window.URL && window.Blob && window.Set && !recentUsedKeyWorker) {
      var pageEle = document.getElementById('page_id');
      var pageid = (pageEle && pageEle.value) || '';
      var tripHost = 'dynamic';
      if (tripHost === 'dynamic') {
          tripHost = (/pro_ctripwireless|ctrip_ctripwireless/.test(navigator.userAgent.toLowerCase()) || /(ctrip|ctripcorp|lvtds)\.com/.test(location.host)) ? 'https://www.ctrip.com' : 'https://www.trip.com';
      }
      function __SHARK_REPORT_WORKER__(tripHost) {
          var xmlHttp = new XMLHttpRequest();
          var xmlHttp2 = new XMLHttpRequest();
          var history_set = new Set();
          var keyinfo_cache = [];
          onmessage = function (e) {
              if (history_set.size < 5000 && !history_set.has(e.data)) {
                  keyinfo_cache.push(e.data);
                  history_set.add(e.data);
              }
          };
          setInterval(function () {
              if (xmlHttp !== null && xmlHttp2 !== null && keyinfo_cache.length > 0) {
                  try {
                      var undefinedKeys = [], recentUsedKeys = [];
                      keyinfo_cache.forEach(function (key) {
                          if (key[0] !== '!') {
                              recentUsedKeys.push(key);
                          } else {
                              undefinedKeys.push(key.substr(1));
                          }
                      });
                      if (recentUsedKeys.length) {
                          xmlHttp.open('POST', tripHost + '/m/i18n/ReportRecentUsedKey.html', true);
                          xmlHttp.setRequestHeader('content-type', 'application/json;charset=utf-8');
                          xmlHttp.send(JSON.stringify(recentUsedKeys));
                      }
                      if (undefinedKeys.length) {
                          xmlHttp2.open('POST', tripHost + '/m/i18n/ReportUndefinedKeys.html', true);
                          xmlHttp2.setRequestHeader('content-type', 'application/json;charset=utf-8');
                          xmlHttp2.send(JSON.stringify(undefinedKeys));
                      }
                      keyinfo_cache = [];
                  } catch (err) {
                  }
              }
          }, 5000);
      }

      recentUsedKeyWorker = new Worker(URL.createObjectURL(new Blob(['(' + __SHARK_REPORT_WORKER__.toString() + ')(' + "'" + tripHost + "'" + ')'])));
  }
} catch (err) {
}
;(function (name, definition) {
  var LANGUAGE = {"cancel":"Cancel","twitter":"Twitter","kakao":"Kakao","whatsApp":"WhatsApp","facebook":"Facebook","google":"Google+","linkedin":"Linkedin","naver":"Naver","copySuccess":"Copied successfully","copy":"Copy","shareLabel":"Share via","email":"Email"};
  if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__) {
      window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__ = {};
  }
  if (!window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100019272']) {
      window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100019272'] = LANGUAGE
  } else {
      if (typeof Object.assign !== 'function') {
          for (var key in LANGUAGE) {
              window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100019272'][key] = LANGUAGE[key]
          }
      } else {
          window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100019272'] = Object.assign(
              window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100019272'],
              LANGUAGE
          )
      }
  }
  var hasDefine = typeof define === 'function' && define.amd,
      hasExports = typeof module !== 'undefined' && module.exports;
  if (hasDefine) {
      if (!window.__shark_app_defined) {
          define(definition);
          window.__shark_app_defined = true;
      }
      define('i18n_100019272', definition);
  } else if (hasExports) {
      module.exports = definition();
  } else {
      this[name] = definition();
  }
})('i18n_100019272', function () {
  var LANGUAGE = window.__SHARK_ARES_SDK_INTERNAL_RESOURCE__['i18n_100019272'];
  if (typeof Proxy === 'function') {
      var LANGUAGE_PROXY = new Proxy(LANGUAGE, {
          get: function (target, property) {
              if (typeof property === 'symbol') {
                  return property;
              } else if (property in target) {
                  if (recentUsedKeyWorker) {
                      recentUsedKeyWorker.postMessage("100019272|en-XX|" + property + (pageid ? '|' + pageid : ''));
                  }
                  if (window.__SHARK_PLUGIN_STATUS__ && window.__SHARK_PLUGIN_STATUS__ === 1) {
                      return '<i data-key=\'' + property + '\' data-appid=\'100019272\'>' + target[property] + '</i>';
                  }
                  return target[property];
              } else {
                  
                  if (recentUsedKeyWorker && property !== '__esModule') {
                      recentUsedKeyWorker.postMessage("!100019272|en-XX|" + property + (pageid ? '|' + pageid : ''));
                  }
                  return null;
              }
          },
          set: function (target, property, value) {
              target[property] = value;
              return true;
          }
      });
      return LANGUAGE_PROXY;
  }
  return LANGUAGE;
});


